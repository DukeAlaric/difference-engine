# Difference Engine — AI-assisted fiction production pipeline
